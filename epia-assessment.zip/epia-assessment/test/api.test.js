const { test, before, after } = require("node:test");
const assert = require("node:assert");
const { openDb } = require("../src/db");
const { createApp } = require("../src/app");

let server, base;

before(async () => {
  const app = createApp(openDb(":memory:"));
  server = app.listen(0);
  base = `http://localhost:${server.address().port}`;
});
after(() => server.close());

const call = (method, path, body) =>
  fetch(base + path, {
    method,
    headers: { "content-type": "application/json" },
    body: body ? JSON.stringify(body) : undefined,
  }).then(async (r) => ({ status: r.status, body: await r.json() }));

const valid = { name: "Test Patient", phone: "+919000000001", date: "2026-11-20" };

test("create and fetch an appointment", async () => {
  const created = await call("POST", "/appointments", valid);
  assert.strictEqual(created.status, 201);
  const got = await call("GET", `/appointments/${created.body.id}`);
  assert.strictEqual(got.status, 200);
  assert.strictEqual(got.body.name, "Test Patient");
});

test("missing fields return 400", async () => {
  const r = await call("POST", "/appointments", { name: "x" });
  assert.strictEqual(r.status, 400);
  assert.ok(r.body.details.length >= 2);
});

test("unknown and non-numeric ids", async () => {
  assert.strictEqual((await call("GET", "/appointments/9999")).status, 404);
  assert.strictEqual((await call("GET", "/appointments/abc")).status, 400);
});

test("reminder success is recorded", async () => {
  delete process.env.WA_SIMULATE;
  const a = await call("POST", "/appointments", valid);
  const r = await call("POST", `/appointments/${a.body.id}/reminder`);
  assert.strictEqual(r.status, 200);
  assert.strictEqual(r.body.status, "sent");
});

test("reminder with bad token fails cleanly and is recorded", async () => {
  process.env.WA_SIMULATE = "token_error";
  const a = await call("POST", "/appointments", valid);
  const r = await call("POST", `/appointments/${a.body.id}/reminder`);
  delete process.env.WA_SIMULATE;
  assert.strictEqual(r.status, 502);
  assert.strictEqual(r.body.error_code, 190);
  const msgs = await call("GET", `/appointments/${a.body.id}/messages`);
  assert.strictEqual(msgs.body[0].status, "failed");
});

test("follow-up lifecycle and duplicate protection", async () => {
  const a = await call("POST", "/appointments", valid);
  const f = { appointment_id: a.body.id, date: "2026-12-01", notes: "Call after scan" };

  const first = await call("POST", "/followups", f);
  assert.strictEqual(first.status, 201);
  assert.strictEqual((await call("POST", "/followups", f)).status, 409);

  const pending = await call("GET", "/followups?status=pending");
  assert.ok(pending.body.some((x) => x.id === first.body.id));

  const done = await call("PATCH", `/followups/${first.body.id}/complete`);
  assert.strictEqual(done.body.status, "completed");
  assert.strictEqual((await call("PATCH", `/followups/${first.body.id}/complete`)).status, 409);

  const pendingAfter = await call("GET", "/followups?status=pending");
  assert.ok(!pendingAfter.body.some((x) => x.id === first.body.id));
});

test("follow-up for missing appointment is 404", async () => {
  const r = await call("POST", "/followups", { appointment_id: 9999, date: "2026-12-01" });
  assert.strictEqual(r.status, 404);
});
