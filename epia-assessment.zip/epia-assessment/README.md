# EPIA Technical Assessment

Small Express + SQLite backend for appointments, WhatsApp reminders (simulated) and follow-ups. All data is fictional.

## Setup

Needs Node 22.5 or newer (I use the built-in `node:sqlite`, so there is no native module to compile).

```bash
npm install
npm start          # http://localhost:3000, data goes to crm.db
npm test           # 7 tests, in-memory DB
```

Env vars: `PORT`, `DB_FILE`, `WA_SIMULATE` (see Task 2).

## Task 1: what was wrong with the original endpoint

1. No `express.json()`, so `req.body` was undefined and the destructuring would throw.
2. `a.id === req.params.id` compares a number with a string, so GET never found anything.
3. No validation of name, phone or date.
4. POST returned plain text with a 200. Now 201 with the created record as JSON.
5. A missing appointment returned `res.json(undefined)`. Now a proper 404.
6. `length + 1` for ids is fragile. SQLite `AUTOINCREMENT` handles it.
7. Everything lived in an array, so a restart wiped it. Now SQLite.

## API examples

```bash
# create
curl -X POST localhost:3000/appointments -H 'content-type: application/json' \
  -d '{"name":"Test Patient 1","phone":"+919000000001","date":"2026-11-20T10:30"}'

# fetch
curl localhost:3000/appointments/1

# validation error -> 400
curl -X POST localhost:3000/appointments -H 'content-type: application/json' -d '{"name":"x"}'

# send reminder, then see the recorded status
curl -X POST localhost:3000/appointments/1/reminder
curl localhost:3000/appointments/1/messages

# follow-ups
curl -X POST localhost:3000/followups -H 'content-type: application/json' \
  -d '{"appointment_id":1,"date":"2026-12-01","notes":"Call after scan"}'
curl 'localhost:3000/followups?status=pending'     # pending | completed | all
curl -X PATCH localhost:3000/followups/1/complete
```

Status codes used: 201 created, 400 bad input, 404 not found, 409 duplicate follow-up or already completed, 502 when the WhatsApp call failed, 500 for anything unexpected.

## Task 2, Part A: the WhatsApp 190 error

**Most likely cause.** Code 190 (`OAuthException`) means Meta rejected the access token. The usual reason is a temporary token from the app dashboard, which expires after about 24 hours. Other possibilities: the token was revoked, belongs to a different app or business account, or the system user lost the `whatsapp_business_messaging` permission.

**How I'd investigate and fix it.**
- Check when the failures started and whether that lines up with a token expiry, a deploy or someone changing app settings.
- Paste the token into Meta's Access Token Debugger (or call `debug_token`) to see whether it is valid, when it expires and what scopes it has.
- Confirm the token is the one actually loaded in production, not an old value in an env file.
- Fix: create a System User in Business Manager, give it access to the WhatsApp account, generate a long-lived token with the right permissions, and store it in a secret manager. Then redeploy and send a test message.

**Accepted by the API but never delivered.** A 200 only means Meta queued it. I'd look at:
- The delivery webhook statuses (`sent`, `delivered`, `read`, `failed`) and the error code on `failed`.
- Whether the user is inside the 24 hour window. Outside it, only an approved template can be sent.
- Template approval status and category.
- Opt-in, and whether the phone number is correct and has WhatsApp.
- Quality rating and messaging limits on the sending number.

**Detecting this early.** Subscribe to the status webhook and store every update. Alert on any 190 or a spike in `failed`. Add a scheduled health check that calls a cheap Graph API endpoint with the token, and alert on token expiry date before it happens. Track the ratio of sent vs delivered per day.

## Task 2, Part B: how it's built

`src/whatsapp.js` has `sendReminder(db, appointment)`. It calls a fake Meta API, writes the result to the `messages` table either way, and never throws, so a failing provider cannot take the app down. Logs only contain the appointment id, error code and message. No tokens, phone numbers or message text.

Try the failure paths:

```bash
WA_SIMULATE=token_error npm start     # returns the 190 error from the brief
WA_SIMULATE=network_error npm start   # generic network failure
```

## Task 3: follow-ups

`followups` table with `UNIQUE (appointment_id, date)`, so duplicates are blocked by the database itself, not only by app code. Pending list is sorted by date. Completing an already completed follow-up returns 409.

## Limitations

- No auth. Anyone who can reach the API can use it.
- WhatsApp is simulated, so no real templates, webhooks or retries.
- No retry or queue for failed reminders. In production I'd use a job queue with backoff.
- No migrations tool, schema is created on startup.
- Phone and date validation is basic (no timezone handling, no country-specific phone rules).
- Phone numbers are stored in plain text. Real patient data would need encryption at rest and an audit trail.
- Tests cover the main flows, not concurrency.
