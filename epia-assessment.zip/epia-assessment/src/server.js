const { openDb } = require("./db");
const { createApp } = require("./app");

const db = openDb();
const app = createApp(db);
const port = process.env.PORT || 3000;

app.listen(port, () => console.log(`Listening on http://localhost:${port}`));

// A bad promise somewhere shouldn't take the whole CRM down
process.on("unhandledRejection", (e) => console.error("[unhandledRejection]", e?.message || e));
