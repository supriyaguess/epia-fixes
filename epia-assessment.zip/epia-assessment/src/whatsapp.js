// Simulated WhatsApp Cloud API. No real credentials involved.
// Set WA_SIMULATE=token_error | undelivered to force a failure, default is success.

async function fakeMetaSend({ to, text }) {
  const mode = process.env.WA_SIMULATE || "ok";

  if (mode === "token_error") {
    const err = new Error("Invalid OAuth access token");
    err.response = {
      error: { message: "Invalid OAuth access token", type: "OAuthException", code: 190 },
    };
    throw err;
  }
  if (mode === "network_error") {
    throw new Error("socket hang up");
  }
  return { messages: [{ id: "wamid." + Math.random().toString(36).slice(2, 12) }], to, text };
}

// Sends a reminder and always records the outcome. Never throws.
async function sendReminder(db, appointment, send = fakeMetaSend) {
  const text = `Hi ${appointment.name}, reminder for your appointment on ${appointment.date}.`;
  let status = "sent";
  let providerId = null;
  let code = null;
  let message = null;

  try {
    const res = await send({ to: appointment.phone, text });
    providerId = res.messages[0].id;
  } catch (e) {
    status = "failed";
    code = e.response?.error?.code ?? null;
    message = e.response?.error?.message ?? e.message;
    // Log the code and message only. Never the token, phone number or message body.
    console.error(`[whatsapp] send failed appointment=${appointment.id} code=${code} msg="${message}"`);
    if (code === 190) {
      console.error("[whatsapp] access token rejected, rotate the token and check permissions");
    }
  }

  const info = db
    .prepare(
      `INSERT INTO messages (appointment_id, status, provider_message_id, error_code, error_message)
       VALUES (?, ?, ?, ?, ?)`
    )
    .run(appointment.id, status, providerId, code, message);

  return {
    id: Number(info.lastInsertRowid),
    appointment_id: appointment.id,
    status,
    provider_message_id: providerId,
    error_code: code,
    error_message: message,
  };
}

module.exports = { sendReminder };
