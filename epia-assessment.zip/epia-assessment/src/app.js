const express = require("express");
const { sendReminder } = require("./whatsapp");

const isDate = (s) => typeof s === "string" && /^\d{4}-\d{2}-\d{2}/.test(s) && !isNaN(Date.parse(s));
const isPhone = (s) => typeof s === "string" && /^\+?\d{7,15}$/.test(s.replace(/[\s-]/g, ""));
const parseId = (v) => (/^\d+$/.test(v) ? Number(v) : null);

function createApp(db) {
  const app = express();
  app.use(express.json());

  const getAppointment = (id) => db.prepare("SELECT * FROM appointments WHERE id = ?").get(id);

  // ---------- Appointments ----------
  app.post("/appointments", (req, res) => {
    const { name, phone, date } = req.body || {};
    const errors = [];
    if (!name || typeof name !== "string" || !name.trim()) errors.push("name is required");
    if (!phone) errors.push("phone is required");
    else if (!isPhone(phone)) errors.push("phone looks invalid");
    if (!date) errors.push("date is required");
    else if (!isDate(date)) errors.push("date must be like 2026-11-20 or 2026-11-20T10:30");
    if (errors.length) return res.status(400).json({ error: "Validation failed", details: errors });

    const info = db
      .prepare("INSERT INTO appointments (name, phone, date) VALUES (?, ?, ?)")
      .run(name.trim(), phone, date);
    res.status(201).json(getAppointment(Number(info.lastInsertRowid)));
  });

  app.get("/appointments/:id", (req, res) => {
    const id = parseId(req.params.id);
    if (id === null) return res.status(400).json({ error: "id must be a number" });
    const appt = getAppointment(id);
    if (!appt) return res.status(404).json({ error: "Appointment not found" });
    res.json(appt);
  });

  // ---------- WhatsApp reminder ----------
  app.post("/appointments/:id/reminder", async (req, res) => {
    const id = parseId(req.params.id);
    if (id === null) return res.status(400).json({ error: "id must be a number" });
    const appt = getAppointment(id);
    if (!appt) return res.status(404).json({ error: "Appointment not found" });

    const result = await sendReminder(db, appt);
    // The request itself worked, the WhatsApp side may not have. 502 tells the caller which.
    res.status(result.status === "sent" ? 200 : 502).json(result);
  });

  app.get("/appointments/:id/messages", (req, res) => {
    const id = parseId(req.params.id);
    if (id === null) return res.status(400).json({ error: "id must be a number" });
    if (!getAppointment(id)) return res.status(404).json({ error: "Appointment not found" });
    res.json(db.prepare("SELECT * FROM messages WHERE appointment_id = ? ORDER BY id").all(id));
  });

  // ---------- Follow-ups ----------
  app.post("/followups", (req, res) => {
    const { appointment_id, date, notes } = req.body || {};
    const errors = [];
    if (!Number.isInteger(appointment_id)) errors.push("appointment_id (number) is required");
    if (!date) errors.push("date is required");
    else if (!isDate(date)) errors.push("date must be like 2026-11-20");
    if (notes !== undefined && typeof notes !== "string") errors.push("notes must be a string");
    if (errors.length) return res.status(400).json({ error: "Validation failed", details: errors });

    if (!getAppointment(appointment_id)) return res.status(404).json({ error: "Appointment not found" });

    try {
      const info = db
        .prepare("INSERT INTO followups (appointment_id, date, notes) VALUES (?, ?, ?)")
        .run(appointment_id, date, notes ?? null);
      const row = db.prepare("SELECT * FROM followups WHERE id = ?").get(Number(info.lastInsertRowid));
      res.status(201).json(row);
    } catch (e) {
      if (String(e.message).includes("UNIQUE")) {
        return res.status(409).json({ error: "A follow-up already exists for this appointment and date" });
      }
      throw e;
    }
  });

  app.get("/followups", (req, res) => {
    const { status = "pending" } = req.query;
    if (!["pending", "completed", "all"].includes(status)) {
      return res.status(400).json({ error: "status must be pending, completed or all" });
    }
    const rows =
      status === "all"
        ? db.prepare("SELECT * FROM followups ORDER BY date").all()
        : db.prepare("SELECT * FROM followups WHERE status = ? ORDER BY date").all(status);
    res.json(rows);
  });

  app.patch("/followups/:id/complete", (req, res) => {
    const id = parseId(req.params.id);
    if (id === null) return res.status(400).json({ error: "id must be a number" });
    const row = db.prepare("SELECT * FROM followups WHERE id = ?").get(id);
    if (!row) return res.status(404).json({ error: "Follow-up not found" });
    if (row.status === "completed") return res.status(409).json({ error: "Follow-up already completed" });

    db.prepare("UPDATE followups SET status = 'completed', completed_at = CURRENT_TIMESTAMP WHERE id = ?").run(id);
    res.json(db.prepare("SELECT * FROM followups WHERE id = ?").get(id));
  });

  // ---------- Fallbacks ----------
  app.use((req, res) => res.status(404).json({ error: "Route not found" }));

  // Bad JSON bodies land here too (body-parser sets err.status = 400)
  app.use((err, req, res, next) => {
    if (err.type === "entity.parse.failed") return res.status(400).json({ error: "Invalid JSON body" });
    console.error("[error]", err.message);
    res.status(500).json({ error: "Something went wrong" });
  });

  return app;
}

module.exports = { createApp };
